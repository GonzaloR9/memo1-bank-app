package com.aninfo.model;

import javax.persistence.*;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private long id;
    @Column(name = "type")
    private String type;
    @Column(name = "amount")
    private double amount;

    @ManyToOne(optional = false)
    @JoinColumn(name = "account_cbu", referencedColumnName = "cbu")
    private Account account;
    public Transaction() {
    }
   public Transaction(Account account, String type, double amount){
        this.account = account;
        this.type = type;
        this.amount = amount;
   }

    public void setId(long id){
        this.id = id;
    }
   public void setType(String type){
        this.type = type;
   }

    public void setAmount(double amount){
        this.amount = amount;
    }

    public long getId(){return this.id;}
    public String getType(){return this.type;}
    public double getAmount(){return this.amount;}

}

